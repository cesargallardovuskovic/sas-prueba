// Utilidades usadas desde Blazor.
window.app = {
  // Descarga un archivo generado en el servidor (bytes en base64).
  descargar: function (nombre, tipo, base64) {
    const bytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
    const url = URL.createObjectURL(new Blob([bytes], { type: tipo }));
    const a = document.createElement('a');
    a.href = url; a.download = nombre; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  },
  imprimir: function () { window.print(); },
  abrir: function (url) { window.open(url, '_blank'); }
};

// Menú lateral colapsable: botón ☰ o tecla F11 (como en el sistema anterior). Se recuerda en este navegador.
window.appMenu = function (forzar) {
  if (window.innerWidth <= 900) { document.body.classList.toggle('menu-visible', forzar); return; }
  const oculto = document.body.classList.toggle('menu-oculto', forzar);
  try { localStorage.setItem('menu-oculto', oculto ? '1' : '0'); } catch (e) { }
};
(function () {
  let guardado = null;
  try { guardado = localStorage.getItem('menu-oculto'); } catch (e) { }
  const aplicar = function () { if (guardado === '1') document.body.classList.add('menu-oculto'); };
  if (document.body) aplicar(); else document.addEventListener('DOMContentLoaded', aplicar);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'F11') { e.preventDefault(); window.appMenu(); }
  });
})();
